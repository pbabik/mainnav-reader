# -*- coding: utf-8 -*-
#
# Copyright (c) 2009, Dennis Keitzel
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
import os
import tempfile
from optparse import OptionParser
import datetime

import helper
from helper import verbose
from helper import die
import communication
import parser
import gpx

def main():
	args = parse_args()
	helper.verbosity = args.verbose
	con = communication.Connection(args.device,)

	if con.open_connection():
		if con.check_device_status():
			if args.download:
				if args.raw:
					raw_data = con.download_data()
					write(((raw_data, 'trackdata.bin'),), args.target_dir, raw=True)
				else:
					raw_data = con.download_data()
					tracks = parser.parse(raw_data, con.logsize)
					if tracks[0]:
						i = 1
						gpx_structures = []
						for track in tracks:
							verbose('creating gpx structure for track #%s.. ' % i, newline=False)
							gpx_structure = gpx.create_gpx_structure(track)
							date = track[0]['time'].strftime('%y-%m-%d_%H:%M')
							gpx_structures.append((gpx_structure, 'track_%s.gpx' % date))
							verbose('ok')
							i += 1
						write(gpx_structures, args.target_dir)
					else:
						print('! tracklog memory is empty !')
						
			elif args.purge:
				con.purge_log_on_device()
			else:
				print('nothing to do..')
	con.close_connection()

def parse_args():
	parser = OptionParser(usage='%prog [Options] <device>', version='%prog 0.1')
	parser.add_option('-p', '--purge',
		dest='purge',
		help='purge the tracklog memory of the device',
		action='store_true',
		default=False)
	parser.add_option('-d', '--download',
		dest='download',
		help='download tracklogs from device',
		action='store_true',
		default=False)
	parser.add_option('-t', '--target-dir',
		dest='target_dir',
		help='target directory for downloaded tracklogs [default: %default]',
		default='%s/mainnav-tracklogs/' % os.environ.get('HOME',
			tempfile.gettempdir()))
	parser.add_option('-v', '--verbose',
		action='store_true',
		dest='verbose',
		default=False,
		help='be verbose')
	parser.add_option('-r', '--raw',
		dest='raw',
		help='store the raw binary data in the target directory (can only be combined with the download option)',
		default=False,
		action='store_true')

	(options, args) = parser.parse_args()

	try:
		options.device = args[0]
	except IndexError:
		options.device = ''
	if not options.device:
		parser.error('please specify device path, for example \'/dev/ttyUSB0\'')
	if options.download and options.purge:
		parser.error('options -d and -p are mutually exclusive')

	return options

def write(datas, path, raw=False):
	try:
		os.chdir(path)
	except OSError as e:
		if path == '%s/mainnav-tracklogs/' % os.environ.get('HOME', tempfile.gettempdir()):
			try:
				os.mkdir(path)
				os.chdir(path)
			except OSError as e:
				die(e)
		else:
			die(e)
	folder = datetime.datetime.now().strftime('%y-%m-%d_%H:%M')
	try:
		os.chdir(folder)
	except OSError:
		try:
			os.mkdir(folder)
			os.chdir(folder)
		except OSError as e:
			die('error while creating folder: \'%s\'' % folder)
	i = 1
	for data in datas:
		filename = data[1]
		fullpath = '%s/%s' % (os.getcwd(),  filename)
		if raw:
			verbose('writing binary data to: \'%s\'.. ' % fullpath, newline=False)
		else:
			verbose('writing track #%s to: \'%s\'.. ' % (i, fullpath), newline=False)
		i += 1
		try:
			while os.path.isfile(filename):
				filename = '%s_another.%s' % (filename[:-4], filename[-3:])
			fd = open(filename, 'w')
			fd.write(data[0])
		except OSError as e:
			die(e)
		finally:
			fd.close()
		verbose('ok')

if __name__ == '__main__':
	print('this is the wrong way')
