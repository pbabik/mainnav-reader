# -*- coding: utf-8 -*-
#
# Copyright (c) 2009, Dennis Keitzel
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
import time
try:
	import serial
except ImportError as e:
	raise SystemExit(e)

from parser import convert_4_byte_big_endian_to_uint
from helper import verbose
from helper import die
from helper import fprint

#commands
CHECK_STATUS = '$3\r\n'
INIT_STANDARD = '\x0f\x06'
INIT_DOWNLOAD = '$1\r\n'
DOWNLOAD_CHUNK = '\x15'
DOWNLOAD_NEXT_CHUNK = '\x06'
PURGE_LOG = '$2\r\n'

#replies
OK = '$OK!\r\n'
FINISH = '$FINISH\r\n'

class Connection():
	def __init__(self, port):
		try:
			self.ser = serial.Serial(
				port=port,
				baudrate=115200,
				parity=serial.PARITY_NONE,
				stopbits=serial.STOPBITS_ONE,
				bytesize=serial.EIGHTBITS)
		except serial.serialutil.SerialException as e:
			die('error: %s' % e)
		self.logsize = 0

	def open_connection(self):
		verbose('opening \'%s\'.. ' % self.ser.port, newline=False)
		self.ser.open()
		success = self.ser.isOpen()
		verbose('ok' if success else 'error')
		return success

	def close_connection(self):
		verbose('closing connection.. ', newline=False)
		self.ser.close()
		success = not self.ser.isOpen()
		verbose('ok' if success else 'error')
		return success

	def check_device_status(self):
		verbose('checking device status.. ', newline=False)
		buf = self.communicate(CHECK_STATUS, waittime=1, bytes=10)
		success = True if OK in buf else False
		verbose('ok' if success else 'error: is the device turned on?')
		if success:
			self.logsize = convert_4_byte_big_endian_to_uint(buf[-4:])
		return success

	def communicate(self, command, waittime=1, bytes=1, answer=True, crc_check=False, crc_retry=0):
		buf = ''
		self.ser.write(command)
		if answer:
			time.sleep(waittime)
			while self.ser.inWaiting():
				buf += self.ser.read(bytes)
			if crc_check:
				if self.crc_check(buf):
					return buf
				else:
					if crc_retry < 3:
						return self.communicate(command, waittime, bytes, answer, crc_check, crc_retry+1)
					else:
						die('error: checksum missmatch during transmission, although three attempts were made')
			else:
				return buf
		else:
			return None
		
	def crc_check(self, buf):
		data = buf[3:-1]
		checksum = ord(buf[-1])
		#TODO: implement :D
		success = True
		return success

	def download_data(self):
		data_buffer = ''
		verbose('switching device to download mode.. ', newline=False)
		if OK in self.communicate(INIT_DOWNLOAD, waittime=1):
			verbose('ok')
			data_buffer = self.communicate(DOWNLOAD_CHUNK, waittime=0.04)[3:-1]
			while True:
				step = 0
				buf = self.communicate(DOWNLOAD_NEXT_CHUNK, waittime=0.04)
				if FINISH in buf:
					break
				else:
					fprint('\rdownloading: %s%%' % int((len(data_buffer) / float(self.logsize)) * 100), newline=False)
					data_buffer += buf[3:-1]
			fprint('')
			verbose('switching device back to standard mode.. ', newline=False)
			time.sleep(0.1)
			self.communicate(INIT_STANDARD, answer=False)
			verbose('ok')
			return data_buffer
		else:
			fprint('error')
			
	def purge_log_on_device(self):
		fprint('purge log on device.. ', newline=False)
		if OK not in self.communicate(PURGE_LOG, waittime=0.2):
			die('error while trying to purge the log')
		else:
			buf = ''
			retry = 0
			while FINISH not in buf and retry < 10:
				time.sleep(1)
				while self.ser.inWaiting():
					buf += self.ser.read()
				retry += 1
			if retry == 10:
				fprint('error')
			else:
				fprint('ok')
